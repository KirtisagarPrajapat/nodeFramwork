let constant = require("./../config/constants")
let niv = require("./niv")
let rn = require("random-number")
let multer = require("multer")
let path = require("path")
const sfet = require('simple-free-encryption-tool');


exports.resObj = (message=constant.msg.successRes,data=[],status=200,is_error=false)=>{
    return {status,is_error,message,data}
}

exports.errObj = (msg=constant.msg.serverErr,status=500,data=[])=>{
    let err = new Error(msg)
    err.errStatus = status
    err.errData = data
    return err
}

exports.rn = (min=1000, max=9999)=>{
    return rn({min,max,integer:true})
}

exports.uploadFile = (req,res,dir,field)=>{
    return new Promise((resolve,reject)=>{
        var storage = multer.diskStorage({
            destination : (req,file,cb)=>{
                cb(null,dir)
            },
            filename : (req,file,cb)=>{
                cb(null,Date.now()+''+this.rn()+path.extname(file.originalname))
            }
        })
        var upload = multer({storage}).array(field)
        upload(req,res,(err)=>{
            if(err){
                resolve(false)
                console.log(err)
            }else{
                resolve(true)
            }
        })

    })
}


exports.encrypt = (data)=>{
    return sfet.aes.encrypt(process.env.secret, JSON.stringify(data))
}

exports.decrypt = (data)=>{
    return JSON.parse(sfet.aes.decrypt(process.env.secret, data))
}

exports.validateInp = (next,inp,rules,msg={})=>{
    return new Promise(async (resolve,reject)=>{
        let v = new niv.Validator(inp,rules,msg)
        let matched = await v.check()
        if(!matched){
            next(this.errObj(Object.values(v.errors)[0].message,400))
        }else{
            resolve(true)
        }
    })

}