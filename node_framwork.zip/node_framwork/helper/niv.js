let constant = require("../config/constants")
let niv = require("node-input-validator")


module.exports = niv