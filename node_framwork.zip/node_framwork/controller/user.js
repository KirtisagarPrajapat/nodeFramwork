
let helper = require("./../helper/common")
let countryModel = require("./../model/countries")
let stateModel = require("./../model/states")
let cityModel = require("./../model/cities")
let constant = require("./../config/constants")

exports.default = (req,res,next)=>{
    next(helper.errObj("Incorrect Route",404))
}
