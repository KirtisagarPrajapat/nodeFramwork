let constant = require("./../config/constants")
let helper = require("./../helper/common")

module.exports = (app)=>{
    app.use((err,req,res,next)=>{
        let status = 500
        let msg = constant.msg.serverErr
        let data = []
        let is_err = true

        if(err.errStatus){
            status = err.errStatus
            msg = err.message
            data = err.errData
        }
        res.status(status).send(helper.resObj(msg,data,status,is_err))

    })
}