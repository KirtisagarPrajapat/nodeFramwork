let fs = require("fs")
let constants = require("./constants")

let mongoose = require("mongoose")
mongoose.connect(process.env.mongoUrl,{useUnifiedTopology:true,useNewUrlParser:true},(err)=>{
    if(!err){
        console.log("db connected...")
    }
})

fs.readdirSync(constants.path.model).forEach((e,i)=>{
    require(constants.path.model+e)
})
