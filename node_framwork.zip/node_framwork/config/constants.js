module.exports = {
    path : {
        model : __dirname+"/../model/",
        uploads : __dirname+"/../uploads/",
    },
    msg : {
        serverErr : "Internal server error.",
        successRes : "Responded successfully.",        
        noData : "No data found.",        
        gotData : "Got data successfully.",        
    }
}