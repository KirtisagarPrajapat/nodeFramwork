let express = require("express")
let app = express()
let http = require("http").Server(app)

app.use(express.json())
app.use(express.urlencoded({extended:true}))

require("./config/db")
let route = require("./routes")
app.use("/api",route)
require("./controller/errContorl")(app)

http.listen(process.env.serverPort,()=>{
    console.log("server on "+process.env.serverPort)
})