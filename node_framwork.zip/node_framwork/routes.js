
let express = require("express")
let Router = express.Router()
let userControl = require("./controller/user")

Router.get("/",userControl.default)

module.exports = Router