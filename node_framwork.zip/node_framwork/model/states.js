let mongoose = require("mongoose")
let stateSchema = new mongoose.Schema({
    id : {
        type : String
    },
    country_id : {
        type : String
    },
    name : {
        type : String
    }
})
let stateModel = mongoose.model("states",stateSchema)

exports.getStates = (cid)=>{
    return new Promise((resolve,reject)=>{
        stateModel.find({country_id:cid},(err,res)=>{
            if(res && res.length>0){
                resolve(res)
            }else{
                resolve(false)
                console.log(err)
            }
        })
    })
}