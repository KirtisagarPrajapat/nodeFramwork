let mongoose = require("mongoose")
let citySchema = new mongoose.Schema({
    id : {
        type : String
    },
    state_id : {
        type : String
    },
    name : {
        type : String
    }
})
let cityModel = mongoose.model("cities",citySchema)

exports.getCities = (sid)=>{
    return new Promise((resolve,reject)=>{
        cityModel.find({state_id:sid},(err,res)=>{
            if(res && res.length>0){
                resolve(res)
            }else{
                resolve(false)
                console.log(err)
            }
        })
    })
}