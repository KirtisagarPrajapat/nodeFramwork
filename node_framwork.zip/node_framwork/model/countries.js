let mongoose = require("mongoose")
let countrySchema = new mongoose.Schema({
    id : {
        type : String
    },
    name : {
        type : String
    }
})
let countryModel = mongoose.model("countries",countrySchema)

exports.getCountries = ()=>{
    return new Promise((resolve,reject)=>{
        countryModel.find((err,res)=>{
            if(res && res.length>0){
                resolve(res)
            }else{
                resolve(false)
                console.log(err)
            }
        })
    })
}